#www.cfcl.ir
print("Not the real win32evtlog")