#www.cfcl.ir
import win32evtlog