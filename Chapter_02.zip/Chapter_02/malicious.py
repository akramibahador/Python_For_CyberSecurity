#www.cfcl.ir
print("I am a malicious program.")
input()